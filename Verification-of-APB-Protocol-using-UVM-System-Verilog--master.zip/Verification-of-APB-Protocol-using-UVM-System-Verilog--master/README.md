# Verification-of-APB-Protocol-using-UVM-System-Verilog-
Developing verification environment in System Verilog to test the functionality of APB protocol using UVM.
